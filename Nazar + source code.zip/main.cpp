#include <windows.h>
#include <cmath>
#include <math.h>
#include <time.h>
// gdi effects
DWORD WINAPI melt(LPVOID lpParam)
{
    while (1) {
        HDC hdc = GetDC(HWND_DESKTOP);
        int sw = GetSystemMetrics(SM_CXSCREEN), sh = GetSystemMetrics(SM_CYSCREEN);
        BitBlt(hdc, rand() % 5, rand() % 5, rand() % sw, rand() % sh, hdc, rand() % 5, rand() % 5, SRCCOPY);
        ReleaseDC(0, hdc);
    }
}
DWORD WINAPI draw(LPVOID lpParam)
{
    while(1){
        HDC hdc = GetDC(HWND_DESKTOP);
        int icon_x = GetSystemMetrics(SM_CXICON);
        int icon_y = GetSystemMetrics(SM_CYICON) ;
        POINT cursor;
        GetCursorPos(&cursor);
        DrawIcon(hdc, cursor.x - icon_x, cursor.y - icon_y, LoadIcon(NULL, IDI_APPLICATION));
        ReleaseDC(0, hdc);
    }
}

// the malware

int main () {
	MessageBoxW(NULL, L"You ran this, now watch these effects.", L"Nazar.exe", MB_OK | MB_ICONASTERISK);
	HANDLE a = CreateThread(0, 0, melt, 0, 0, 0);
	HANDLE b = CreateThread(0, 0, draw, 0, 0, 0);
	Sleep(15000);
	TerminateThread(a, 0);
	TerminateThread(b, 0);
}
